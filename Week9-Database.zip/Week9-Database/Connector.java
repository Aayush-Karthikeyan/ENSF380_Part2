package edu.ucalgary.oop;/*
 * Connector.java
 * Singleton managing the PostgreSQL database connection.
 * Reads connection details from src/main/resources/db.config.
 *
 * Author: Dave Bugoin
 * Version: 1.0
 * Date: 2026-03-10
 */

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

/**
 * Singleton PostgreSQL database connection.
 * Connection details are read from db.config in resources.
 */
public class Connector {

    private static Connector instance;
    private Connection connection;
    private String username;
    private String password;
    private String url;

    private Connector() {
        //Properties props = new Properties();
        /*
        InputStream input = Connector.class.getClassLoader()
            .getResourceAsStream("db.config");
        if (input == null) {
            throw new Exception("db.config not found in resources");
        }
        props.load(input);

         */
    }
    public void Connect() throws Exception {
        String url      = instance.url;
        String username = instance.username;
        String password = instance.password;
        Class.forName("org.postgresql.Driver");
        this.connection = DriverManager.getConnection(url, username, password);
    }
    public void setInfo(String url,String userName,String password){
        this.url = url;
        this.password = password;
        this.username = userName;
    }

    public static Connector getInstance() throws Exception {
        if (instance == null) {
            instance = new Connector();
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }
}
